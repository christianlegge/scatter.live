Extract to a folder and open zootr-sim.html in a browser to play.

Report an issue on https://github.com/scatter-dev/scatter.live/issues if there 
are any. Please put "offline sim" or something like that in the title.

Special thanks to Brandon Sedge and his weird internet issue.